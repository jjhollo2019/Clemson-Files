 "I have read the CPSC/ECE 3520 SSII 2019 course syllabus."
