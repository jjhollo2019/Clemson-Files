/* Author: Jeremy Holloway / jjhollo
*  CPSC-1071001
*  Lab 11
*  Due Date: 4/13/2018
*  Description: This file holds to the functions to be called by the main
*/

#include "matrix.h"
#include <cfloat>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <ostream>

/* Function: Matrix
*  Description: This function is the default constructor
*/
Matrix::Matrix(int r, int c){
	rows = r;
	cols = c;
	mat = new double*[rows];
	for(int i = 0; i < rows; i++) {
		mat[i] = new double[cols]();
	}
}

/* Function: Matrix
*  Description: This function will make a copy
*/
Matrix::Matrix(const Matrix& rhs) 
{
	for(int i = 0; i < rows; i++) {
		delete[] mat[i];
	}

	delete[] mat;

	rows = rhs.rows;
	cols = rhs.cols;

	mat = new double*[rows];
	for(int i = 0; i < rows; i++) {
		mat[i] = new double[cols]();
	}

	for(int i = 0; i < rows; i++) {
		for(int j = 0; j < cols; j++) {
			mat[i][j] = rhs[i][j];
		}
	}
}

/* Function: ~Matrix
*  Description: This function is the destructor
*/
Matrix::~Matrix(){
}

/* Function: opertor +
*  Description: This function will add two matrices
*/
Matrix Matrix::operator+(const Matrix& rhs){
	int a, b;
	Matrix sum(rows, rhs.cols);
	if(cols == rhs.cols){
		for(a = 0; a < rows; a++){
			for(b = 0; b < sum.cols; b++){
				sum[a][b] = mat[a][b] + rhs[a][b];
			}
		}
	}		
	return sum; 
}

/* Function: operator -
*  Description: This function will subtract two matrices
*/
Matrix Matrix::operator-(const Matrix& rhs){
	int a, b;
	Matrix diff (rows, rhs.cols);
	if(cols == rhs.cols){
		for(a = 0; a < rows; a++){
			for(b = 0; b < diff.cols; b++){
				if(mat[a][b] > rhs[a][b])
					diff[a][b] = mat[a][b] - rhs[a][b];
				else
					diff[a][b] = rhs[a][b] - mat[a][b];
			}	
		}
	}
	return diff;	 
}

/* Function: operator *
*  Description: This function multiplies two matrices
*/
Matrix Matrix::operator*(const Matrix& rhs){
	Matrix result (rows, rhs.cols);
    if(cols == rhs.rows)
    {
        for(int i = 0; i < result.rows; i++)
        {
            for(int j = 0; j < result.cols; j++)
            {
                for(int k = 0; k < cols; k++) 
                {
                    result[i][j] += mat[i][k] * rhs[k][j];
                }
            }
        }
    }

    return result;
}

/* Function: print
*  Description: This function prints out the matrix
*/
void Matrix::print(){
	std::cout.setf(std::ios::fixed, std::ios::floatfield);
	std::cout.precision(2);
	for(int i = 0; i < rows; i++) {
		std::cout << "[";
		for(int j = 0; j < cols; j++) {
			std::cout.width(0);
			j == getCols()-1 ? std::cout << (*this)[i][j] : 
				std::cout << (*this)[i][j] << ", ";
		}
		std::cout << "]" << std::endl;
	}
}

/* Function: operator []
*  Description: This function gives us to acces the matrix using a
*  closed bracket operator
*/
double* Matrix::operator[](int row){
	return mat[row];
}

/* Function: operator []
*  Description: This function gives us to access the matrix using a
*  closed bracket perator
*/
const double* Matrix::operator[](int row) const{
	return mat[row];
}

/* Function: getRows
*  Description: This function will return the number of rows
*/
int Matrix::getRows() const{
	return rows;
}

/* Function: getCols
*  Description: This function will return the number of columns
*/
int Matrix::getCols() const{
	return cols;
}

/* Function: transpose
*  Description: This function will reverse the order of the matrix
*/
Matrix Matrix::transpose() const{
	int a, b;
	Matrix trans(rows, cols);
	for(a = 0; a < rows; a++){
		for(b = 0; b < cols; b++){
			trans[b][a] = mat[a][b];
		}
	}
	return trans;
}
