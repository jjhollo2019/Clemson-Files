/* Author: Jeremy Holloway / jjhollo
*  CPSC-1071-001 
*  Lab 10
*  Due Date: 4/7/2018
*  Description: This file holds the functions for the iterator class
*/

#include <iostream>
#include "node.h"
#include "list.h"
#include "iterator.h"

using namespace std;

/* Function: Iterator
*  Description: This function is the default constructor
*/
Iterator::Iterator(){
	list = NULL;
	current = NULL;
}

/* Function: Iterator
*  Description: This function is a constructor with a passed list
*/
Iterator::Iterator(List *inList){
	list = inList;
	current = list->getHead();
}

/* Function: ~Iterator
*  Description: This function is the destructor
*/
Iterator::~Iterator(){
}

/* Function: advance
*  Description: This function will replace the current node with the next node
*/
void Iterator::advance(){
	current = current->getNext();
}

/* Function: hasNext
*  Description: This function will determine if the current node has data
*  and return true if it does
*/
bool Iterator::hasNext(){
	bool next = true;
	if(current == NULL){
		next = false;
	}
	return next;
}

/* Function: get
*  Description: This function will return the current node
*/
Node* Iterator::get(){
	return current;
}
