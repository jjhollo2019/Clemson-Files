/* Author: Jeremy Holloway / jjhollo
*  CPSC-1071-001
*  Lab 10
*  Due Date: 4/7/2018
*  Description: This file holds the functions for the list class 
*/

#include "list.h"
#include "node.h"
#include "iterator.h"
#include <cstring>
#include <iostream>

using namespace std;

/* Function: List
*  Description: This function is the default constructor
*/
List::List(){
	head = NULL;
	current = NULL;
}

/* Function: ~List
*  Description: This function is the destructor
*/
List::~List(){
    if(head != NULL) {
        Node* cur = head;
        while(cur != NULL) {
            std::cout << "removing list item" << std::endl;
            Node* tmp = cur->getNext();
            delete cur;
            cur = tmp;
        }
    }
}

/* Function: addFirst
*  Description: This function will create a new node and add it to the 
*  front of the list
*/
void List::addFirst(void* obj){
	Node *temp = new Node(obj);
	temp->setNext(head);
	head = temp;
}

/* Function: reset
*  Description: This function will reset the list to the head node
*/
void List::reset(){
	current = head;
}

/* Function getCurItem
*  Description: This function will return the item value stored in the 
*  current node
 */
void* List::getCurItem(){
	return current->getItem();
}

/* Function: getHead
*  Description: This function will return the head node
 */
Node* List::getHead(){
    return head;
}
