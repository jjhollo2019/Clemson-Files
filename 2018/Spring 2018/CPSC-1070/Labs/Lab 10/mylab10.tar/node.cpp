/* Author: Jeremy Holloway / jjhollo
*  CPSC-1071-001 
*  Lab 10
*  Due Date: 4/7/2018
*  Description: This file holds the functions needed for the node class
*/

#include "node.h"
#include "list.h"
#include "iterator.h"
#include <cstring>

/* Function: Node
*  Description: This function is the default constructor
*/
Node::Node(){
	item = NULL;
	next = NULL;
}

/* Function: Node
*  Description: This function is a constructor with a void pointer
*/
Node::Node(void* itm){ 
	item = (Node *) itm;
	next = NULL;
}

/* Function: ~Node
*  Description: This function is the destructor
*/
Node::~Node(){
    // left blank intentionally.
}

/* Function: getNext
*  Description: This function returns the next value 
*/
Node* Node::getNext(){
	return next;
}

/* Function: getItem
*  Decription: This function returns the item value
*/
void* Node::getItem(){
	return item;
}

/* Function: setNext
*  Description: sets the next variable to the passed parameter
*/
void Node::setNext(Node* n){
	next = n;
}
