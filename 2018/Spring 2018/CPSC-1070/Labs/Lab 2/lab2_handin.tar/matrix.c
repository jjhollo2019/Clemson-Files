/*
 * File: matrix.c
 * Name: Jeremy Holloway
 * Description: This program will add, subtract, multiply, and transpose a matrix.
 * Date: 1/26/2018
 */
#include "matrix.h"

/*
 * Function: matrix_print(char*, double[3][3])
 * Description: This function will loop through the matrix and print each element 
 * and print each one to the screen
 */
void matrix_print(char* label, double m[3][3]) 
{
	int a, b;
	printf("%s", label);
	for(a = 0; a < 3; a++){
		for(b = 0; b < 3; b++){
		   printf(" %.03f", m[a][b]);
		   if(b == 2)
		     printf("\n\n");
		}
	}
}

/*
 * Function: matrix_copy(double[3][3], double[3][3])
 * Description: This function will loop through the array and copy one matrix into another
 */
void matrix_copy(double m[3][3], double result[3][3]) 
{
	int a, b;
	for(a = 0; a < 3; a++){
		for(b = 0; b < 3; b++){
			result[a][b] = m[a][b];
		}
	}
}

/*
 * Function: matrix_sum(double[3][3], double[3][3], double[3][3])
 * Description: This function will loop through the array and add two matrices together
 */
void matrix_sum(double m1[3][3], double m2[3][3], double result[3][3]) 
{
	int a, b;
	for(a = 0; a < 3; a++){
		for(b = 0; b < 3; b++){
		result[a][b] = m1[a][b] + m2[a][b];
		}
	}
}

/*
 * Function: matrix_difference(double[3][3], double[3][3], double[3][3])
 * Description: This function will loop through the array and subtract two matrices
 */
void matrix_difference(double m1[3][3], double m2[3][3], double result[3][3])
{
	int a, b;
	for(a = 0; a < 3; a++){
		for(b = 0; b < 3; b++){
		result[a][b] = m1[a][b] - m2[a][b];
		}
	}	
}

/*
 * Function: matrix_multiply(double[][], double[][], double[][])
 * Description: This function will loop throught the array and multiply two matrices
 */
void matrix_multiply(double m1[3][3], double m2[3][3], double result[3][3]) 
{
	int a, b, c;
	for(a = 0; a < 3; a++){
		for(b = 0; b < 3; b++){
		   result[a][b] = 0;
			for(c = 0; c < 3; c++)
		result[a][b] += m1[a][c] * m2[c][b]; 
		}
	}
}

/*
 * Function: matrix_scale(double[], double)
 * Description: This function will loop through the array and multiply each element by the 
 * assigned scalar
 */
void matrix_scale(double m[3][3], double scale) 
{
	int a, b;
	for(a = 0; a < 3; a++){
		for(b = 0; b < 3; b++){
		m[a][b] = m[a][b] * scale;
		}
	}
}

/*
 * Function: matrix_transpose(double[])
 * Description: This function will loop through the array and reverse the 
 * element assignments
 */
void matrix_transpose(double m[3][3]) 
{
	int a, b;
	double holder[3][3];
	for(a = 0; a < 3; a++){
		for(b = 0; b < 3; b++){
		holder[a][b] = m[a][b];
		}
	}
			for(a = 0; a < 3; a++){
				for(b = 0; b < 3; b++){
				   m[b][a] = holder[a][b];
				}	
			}
}

/*
 * Function: matrix_is_symmetric(double[])
 * Description: This function will transpose an array and verify the diagonal sides
 * are the same, and return a value for either
 */
int matrix_is_symmetric(double m[3][3]) 
{
	int a, b;
	matrix_transpose(m);
	for(a = 0; a < 3; a++){
		for(b = 0; b < 3; b++){
			if(m[a + 1][b] == m[a][b + 1] && m[a + 2][b] == m[a][b + 2] && 
		  	  m[a + 1][b + 2] == m[a + 2][b + 1])
		  	return 1;
			else
		  	return 0;
		}	
	}
}
