#ifndef CANDY_H
#define CANDY_H

#include "dessert.h"
#include "dessertItem.h"

class Candy : public DessertItem
{
  public:
   Candy();
   Candy(std::string candyname, Weight w, Money price);
   Candy(std::ifstream &infile);
   ~Candy();
   Money getCost();
   void print();

  private:
   Weight wt;
   Money pricePerPound;
}; 
   
#endif
