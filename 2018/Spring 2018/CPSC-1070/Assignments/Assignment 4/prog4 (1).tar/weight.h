#ifndef WEIGHT_H
#define WEIGHT_H

class Weight
{
  public:
   Weight();
   Weight(int p, int w);
   Weight(double wt);

   int getPounds();
   int getOunces();
   void setPounds(int lbs);
   void setOunces(int oz);
   bool lessThan(Weight wt);
   bool operator<(Weight w);

   private:
     int pounds;
     int ounces;
};

#endif
