/*
  CPSC 1070
  class Checkout
  Partially completed
  Will read all dessert items for a customer and place the
  items in the vector

*/

#include "dessert.h"
#include "dessertItem.h"
#include "checkout.h"
#include "candy.h"
#include "cookie.h"
#include "iceCream.h"

using namespace std;

Checkout::Checkout()
 {}

Checkout::Checkout(ifstream &infile)
{
   loadDesserts(infile);
}

/* clears the Checkout to begin checking */
void Checkout::clear()   
{
   /* STUBBED.  Use the clear() method for the vector class  */ 
}

/**
    a DessertItems are added to the end of the list of items
 **/
void Checkout::loadDesserts(ifstream &infile)
{
   string token;
   DessertItem *dessert;

   /* Start processing DessertItems */


   infile >> token;
   infile.get();
  
   while (token.compare(";") != 0)
   {
      if(token.compare("candy") == 0)
      {
         dessert = new Candy(infile);
      }   
      else if (token.compare("cookie") == 0)
      {
         dessert = new Cookie(infile);
      } 
      else if(token.compare("iceCream") == 0)
      {
         dessert = new IceCream(infile);
      }
      else if (token.compare("sundae") == 0)
      {
         dessert = new Sundae(infile);
      } 
      else
      {
         cerr << "Unknown token " << token << endl;
         exit(1);
      }


      itemsVector.push_back(dessert);
      
      infile >> token;
      infile.get();
    }
}


int Checkout::numberOfItems() 
{
   
   /*  STUBBED.  To be completed for program 4  */

}


void  Checkout::printReceipt()  
{
    /* STUBBED.  To be completed for program 4  */

}

                      
Money Checkout::totalCost() 
{ 
   /* STUBBED.  To be completed for program 4  */
}
      
Money Checkout::totalTax()  // returns total tax on items
{
   
   /* STUBBED.  To be completed for program 4  */
   /* Use the tax rate in dessert.h            */    
   
}
                             
