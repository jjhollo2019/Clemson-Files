#include "money.h"

using std::cout;
using std::endl;

Money::Money() 
{
   dollars = 0;
   cents = 0;
}

Money::Money(double amt) 
{
   int amount = (int) ((amt + 0.005) * 100);
   dollars = amount / 100;
   cents = amount % 100;
}

Money::Money(int d, int c) 
{ 
   dollars = d;
   cents = c;
}

Money::~Money( ) 
{ }

int Money::getDollars() 
{
   return dollars;
}

int Money::getCents() 
{
   return cents;
}

void Money::set(int d, int c) 
{
   dollars = d;
   cents = c;
}
 
int Money::valueInCents() 
{
   int amt;
   amt = dollars * 100 + cents;
   return amt;
}

double Money::dollarsAndCents() 
{
    double amt = dollars + 0.01 * cents;
    return amt;
}

Money Money::add(Money other)
{
   Money sum;

   sum.dollars = sum.dollars + dollars + other.dollars;
   int pennies = cents + other.cents;

   if(pennies >= 100)
   {
      sum.dollars = sum.dollars + pennies / 100;
      sum.cents = pennies % 100;
   }
   else
     sum.cents = pennies;

   return sum;
}

Money Money::operator+(Money other)
{
   return this->add(other);
}
