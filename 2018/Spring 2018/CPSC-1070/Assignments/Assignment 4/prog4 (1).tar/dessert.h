#ifndef DESSERT_H
#define DESSERT_H


using namespace std;


#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>
#include <vector>
#include <cassert>
#include "money.h"
#include "weight.h"

#define TAX_RATE 0.08
#define WIDTH 30
#define NAME_WIDTH 30


#endif
