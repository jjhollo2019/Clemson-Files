/**
 * CPSC 1070 - Program 4
 * Abstract base class for Dessert Item hierarchy
 */
  
#include "dessertItem.h"
#include "dessert.h"
 
 
  
/**
 * Default  constructor for DessertItem class
 */
DessertItem::DessertItem() 
{
    name = "";
}

/**
 * Initializes DessertItem data
 */   
DessertItem::DessertItem(std::string dessertName) 
{
   name = dessertName;
}

DessertItem::DessertItem(ifstream &infile)
{
   getline(infile, name);
}

DessertItem::~DessertItem()
{}

/**
 * Returns name of DessertItem
 */  
string DessertItem::getName() 
{
   return name;
}
 
void DessertItem::print()
{
   std::cout << "Name: " << name << std::endl;
}
