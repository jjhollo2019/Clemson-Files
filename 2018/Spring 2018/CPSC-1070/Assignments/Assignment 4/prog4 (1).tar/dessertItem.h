#ifndef DESSERT_ITEM_H
#define DESSERT_ITEM_H

#include "dessert.h"

/**
 * CPSC 1070
 * Abstract base class for Dessert Item hierarchy
 * 
 */

class DessertItem 
{
 public: 
   DessertItem(); 
   DessertItem(std::string dessertName);
   DessertItem(ifstream &infile); 
   virtual ~DessertItem();
   std::string getName();
   virtual Money getCost() = 0;
   virtual void print();

  protected:
     std::string name;
};

#endif
