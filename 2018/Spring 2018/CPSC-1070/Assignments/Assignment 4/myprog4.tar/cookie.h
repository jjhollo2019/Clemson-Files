/* Author: Jeremy Holloway / jjhollo
 * CPSC-1070-001
 * Program 4
 * Due Date: 4/26/2018
 * Decription: This is the header file for the cookie class
 */

#ifndef COOKIE_H
#define COOKIE_H

#include "dessert.h"
#include "dessertItem.h"

class Cookie : public DessertItem {
	public: 
		Cookie();
		Cookie(std::string cookiename, int quantity, Money price);
		Cookie(std::ifstream &infile);
		~Cookie();
		Money getCost();
		void print();

	private:
		Money pricePerPound;
		int quantity;
};

#endif
