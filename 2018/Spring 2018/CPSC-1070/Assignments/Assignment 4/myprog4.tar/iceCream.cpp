/* Author: Jeremy Holloway / jjhollo
 * CPSC-1070-001
 * Program 4
 * Due Date: 4/26/2018
 * Description: This file holds the definitions for the icecream class
 */

#include <string>
#include <iostream>
#include "iceCream.h"
#include "dessert.h"
#include "dessertItem.h"
#include "weight.h"
#include "money.h"

using namespace std;

/* Function: iceCream
 * Description: This function is the default constructor
 */
IceCream::IceCream(){
	pricePerPound = Money();
}

/* Function: icecream
 * Description: This function is a constructor that passes candy name,
 * weight, and price
 */
IceCream::IceCream(std::string icecreamname, Money price)
: DessertItem(icecreamname){
	pricePerPound = Money(price);
}

/* Function: icecream
 * Description: This function is a constructor that passes the information
 * from a file
 */
IceCream::IceCream(std::ifstream &infile) : DessertItem(infile){
	std::string temp;
	getline(infile, temp);
	pricePerPound = Money((double)atof(temp.c_str()));
}

/* Function: ~iceCream
 * Description: This function is the destructor 
 */
IceCream::~IceCream(){
}

/* Function: getCost
 * Description: This function will return the total price
 */
Money IceCream::getCost(){
	return pricePerPound;
}

/* Function: print
 * Description: This function will print the item's weight, price per pound, 
 * and the name
 */
void IceCream::print(){
	Money cost = IceCream::getCost();
	DessertItem::print();
	std::cout << "\t   " << cost.getDollars() << "." << cost.getCents() 
	<< std::endl;
}	
