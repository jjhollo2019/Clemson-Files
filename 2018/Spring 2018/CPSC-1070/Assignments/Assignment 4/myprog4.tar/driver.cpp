// TestCheckout.cpp - main method to test Checkout class
//                         and DessertItem hierarchy

#include <iostream>
#include <cassert>
#include "checkout.h"

int main(int argc, char *argv[])
{  
   int i;
   int customers;

   ifstream infile;

   if(argc != 2)
   {
      cerr << "Usage: ./p4 infile days" << endl;
      exit(1);
   }

   infile.open(argv[1], ios::in);

    //assert(infile != NULL);
     
    infile >> customers;
    infile.get();
    
    Checkout checkout(infile);
    checkout.printReceipt();
    checkout.clear();

    for(i = 1; i < customers; i++)
    {
       checkout.loadDesserts(infile);    
       checkout.printReceipt();
       checkout.clear();
    }
       
     return 0;
}

