/* Author: Jeremy Holloway / jjhollo
 * CPSC-1070-001
 * Program 4
 * Due Date: 4/26/2018
 * Description: This file holds the implementations for the sundae class
 */

#include <iostream>
#include <string>
#include "sundae.h"
#include "iceCream.h"
#include "dessert.h"
#include "dessertItem.h"
#include "weight.h"
#include "money.h"

using namespace std;

/* Function: Sundae
 * Description: This function is the default constructor
 */
Sundae::Sundae(){
	topCost = Money();
}

/* Function: Sundae
 * Description: This function is a constructor that is passed a name, weight
 * and price
 */
Sundae::Sundae(std::string sundaename, Money price){
	topCost = Money(price);
}

/* Function: Sundae
 * Description: This function will create new items as they're read from
 * the input file
 */
Sundae::Sundae(std::ifstream &infile){
	std::string temp;
	getline(infile, temp);
	wt = Weight((double)atof(temp.c_str()));
	getline(infile, temp);
	pricePerPound = Money((double)atof(temp.c_str()));
}

/* Function: ~Sundae
 * Description: This function is the destructor 
 */
Sundae::~Sundae(){
}

/* Function: getCost
 * Description: This function will return the cost of the sundae
 */
Money Sundae::getCost(){
	double cost;
	cost = ((double) wt.getPounds() + (wt.getOunces() / 10))
	* pricePerPound.dollarsAndCents();
	std::cout << cost;
}

/* Function: print
 * Description: This function will print the item's weight, price, 
 * and the name
 */
void Sundae::print(){
	std::cout << setw(NAME_WIDTH) << wt.getPounds() << " lbs " << 
	wt.getOunces() << " oz @\t" << pricePerPound.getDollars() << "." <<
	pricePerPound.getCents() << " \\lb." << std::endl;
	DessertItem::print();
} 
