/* Author: Jeremy Holloway / jjhollo
 * CPSC 1070
 * Program 4
 * Due Date: 4/26/2018
 * description: This file holds the definitions for the checkout class
 *
 */

#include <iostream>
#include <vector>
#include "dessert.h"
#include "dessertItem.h"
#include "checkout.h"
#include "candy.h"
#include "cookie.h"
#include "iceCream.h"
#include "sundae.h"

using namespace std;

/* Function: Checkout
 * Description: This function is the default constructor 
 */
Checkout::Checkout(){
}

/* Function: Checkout
 * Description: This function is the constructor with passed input from
 * a file
 */
Checkout::Checkout(ifstream &infile){
   loadDesserts(infile);
}

/* Function: clear
 * Description: This function will clear the checkout items
 */
void Checkout::clear(){
	itemsVector.clear();
}

/* Function: loadDesserts
 * Description: This function adds dessertItems to the end of the list
 */
void Checkout::loadDesserts(ifstream &infile){
   string token;
   DessertItem *dessert;

   /* Start processing DessertItems */


   infile >> token;
   infile.get();
  
   while (token.compare(";") != 0)
   {
      if(token.compare("candy") == 0)
      {
         dessert = new Candy(infile);
      }   
      else if (token.compare("cookie") == 0)
      {
         dessert = new Cookie(infile);
      } 
      else if(token.compare("iceCream") == 0)
      {
         dessert = new IceCream(infile);
      }
      else if (token.compare("sundae") == 0)
      {
         dessert = new Sundae(infile);
      } 
      else
      {
         cerr << "Unknown token " << token << endl;
         exit(1);
      }


      itemsVector.push_back(dessert);
      
      infile >> token;
      infile.get();
    }
}

/* Function: numberOfItems
 * Description: This function will return the number of items
 */
int Checkout::numberOfItems(){
	int a = 0;
	int sum = 0;
	for(a = 0; a < itemsVector.size(); a++){
		sum++;
	}
   	return sum;
}

/* Function: printReceipt
 * Description: This function will print an itemized receipt of all items
 */
void  Checkout::printReceipt(){
	Money total;
	Money tax;
	int a = 0;
	int items = Checkout::numberOfItems();
	std::cout << std::endl;
	std::cout << std::endl;
	std::cout << setw(NAME_WIDTH) << "    CPSC1070 Dessert Shoppe    " 
	<< std::endl;
	std::cout << setw(NAME_WIDTH)  << left << "          Receipt:" 
	<< std::endl;
	std::cout << setw(NAME_WIDTH) << "==============================="
	<< std::endl;
	for(a = 0; a < itemsVector.size(); a++){
		DessertItem *temp = itemsVector.at(a);
		temp->print();
		total.add(temp->getCost());
	}
	//tax.totalTax(total);
	std::cout << std::endl;
	std::cout << setw(NAME_WIDTH) << left << "Number of Items:" << items 
	<< std::endl;
	std::cout << std::endl; 
	std::cout << setw(NAME_WIDTH) << left << "Total Cost:   " 
	<< total.dollarsAndCents() << std::endl;
	//cout << setw(NAME_WIDTH) << left << "Total Tax:";
	//cout << setw(NAME_WIDTH) << right << total.dollarsAndCents() << endl;
	std::cout << setw(NAME_WIDTH) << left << "Cost + Tax:" << 
	total.dollarsAndCents() << std::endl; 
	
}

/* Function: totalCost
 * Description: This function will return the total cost
 */                      
Money Checkout::totalCost(){
	int a = 0;
	Money total;
	Money current;
	for(a = 0; a < itemsVector.size(); a++){
		DessertItem *temp = itemsVector.at(a);
		current = temp->getCost();
		total.add(current); 
	}
	return total;
}
      
Money Checkout::totalTax(){
	Money temp = Checkout::totalCost();
	Money total = Money(temp.dollarsAndCents() * TAX_RATE);
	return total;    
}
                             
