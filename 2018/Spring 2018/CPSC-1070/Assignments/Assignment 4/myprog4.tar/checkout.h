#ifndef CHECKOUT_H
#define CHECKOUT_H

#include "dessertItem.h"
#include "candy.h"
#include "cookie.h"
#include "iceCream.h"
#include "dessert.h"

class Checkout
{
  public:
    Checkout(); // creates an empty list of DessertItems
    void clear();  // clears the Checkout to begin checking
                   // out a new set of items

    Checkout(ifstream &infile);

   /** 
     reads each dessert and puts it at the end of the list of 
     dessert items 
    **/
    void loadDesserts(ifstream &infile); 


    /**
       returns the number of items.
     **/
    int numberOfItems();

    /**
       prints the receipt
     **/
    void printReceipt();

    /**
      returns the total cost as Money
     */
    Money totalCost(); 

   /**
     returns total tax on items
   **/
     Money totalTax();
    

private: 
   vector<DessertItem *> itemsVector; 
}; 


#endif
