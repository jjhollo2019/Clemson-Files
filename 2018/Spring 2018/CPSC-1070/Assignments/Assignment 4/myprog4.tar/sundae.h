/* Author: Jeremy Holloway / jjhollo
 * CPSC-1070-001
 * Program 4
 * Due Date: 4/26/2018
 * Description: This file holds the definitions for the sundae class
 */

#ifndef SUNDAE_H
#define SUNDAE_H

#include "dessert.h"
#include "iceCream.h"
#include "dessertItem.h"

class Sundae : public IceCream {
	public:
		Sundae();
		Sundae(std::string sundaename, Money price);
		Sundae(std::ifstream &infile);
		~Sundae();
		Money getCost();
		void print();

	private:
		Money topCost;
};

#endif
