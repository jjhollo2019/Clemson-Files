#ifndef MONEY_H
#define MONEY_H

#include <iostream>
#include <cstdlib>
#include <cmath>

using  std::cout;
using  std::endl;

class Money  {

   public:
      Money();

      Money(double amt);
      Money (int dollars, int cents);
      ~Money();
   
      int getDollars( );
      int getCents();
      void set(int d, int c);
      int valueInCents();
      double dollarsAndCents();
      Money add(Money other);
      Money operator+(Money other);


   private:
      int dollars;
      int cents;
};

#endif
