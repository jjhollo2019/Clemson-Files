/* Author: Jeremy Holloway / jjhollo
 * CPSC-1070-001
 * Program 4
 * Due Date: 4/26/2018
 * Decription: This is the header file for the icecream class
 */

#ifndef ICECREAM_H
#define ICECREAM_H

#include "dessert.h"
#include "dessertItem.h"

class IceCream : public DessertItem {
	public: 
		IceCream();
		IceCream(std::string icecreamname, Money price);
		IceCream(std::ifstream &infile);
		~IceCream();
		Money getCost();
		void print();

	protected:
		Money pricePerPound;
};

#endif

