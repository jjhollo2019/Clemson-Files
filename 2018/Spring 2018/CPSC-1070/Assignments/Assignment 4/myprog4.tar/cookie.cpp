/* Author: Jeremy Holloway / jjhollo
 * CPSC-1070-001
 * Program 4
 * Due Date: 4/26/2018
 * Description: This file holds the implementations for the cookie class
 */

#include <string>
#include <iostream>
#include "cookie.h"
#include "dessert.h"
#include "dessertItem.h"
#include "weight.h"
#include "money.h"

using namespace std;

/* Function: Cookie
 * Description: This function is the default constructor
 */
Cookie::Cookie(){
	pricePerPound = Money();
	quantity = 0;
}

/* Function: Cookie
 * Description: This function is a constructor that passes candy name,
 * weight, and price
 */
Cookie::Cookie(std::string cookiename, int qty, Money price)
: DessertItem(cookiename){
	pricePerPound = Money(price);
	quantity = qty;
}

/* Function: Cookie
 * Description: This function is a constructor that passes the information
 * from a file
 */
Cookie::Cookie(std::ifstream &infile) : DessertItem(infile){
	std::string temp;
	getline(infile, temp);
	quantity = atoi(temp.c_str());
	getline(infile, temp);
	pricePerPound = Money((double)atof(temp.c_str()));
}

/* Function: ~Cookie
 * Description: This function is the destructor 
 */
Cookie::~Cookie(){
}

/* Function: getCost
 * Description: This function will return the total price
 */
Money Cookie::getCost(){
	Money cost;
	cost = Money((double) (quantity / 12.0)  * 
	pricePerPound.dollarsAndCents());
	return cost;
}

/* Function: print
 * Description: This function will print the items weight, price per pound, 
 */
void Cookie::print(){
	Money cost = Cookie::getCost();
	std::cout << "qty: " << quantity << " @ " << pricePerPound.getDollars() 
	<< "." << pricePerPound.getCents() << " / doz" << std::endl;
	DessertItem::print();
	std::cout << "\t" << cost.getDollars() << "." << 
	cost.getCents() << std::endl;
}
