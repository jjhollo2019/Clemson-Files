/* Author: Jeremy Holloway / jjhollo
 * CPSC-1070-001
 * Program 4
 * Due Date: 4/26/2018
 * Description: This file holds the definitions for the candy class
 */

#include <fstream>
#include <string>
#include <iostream>
#include "candy.h"
#include "dessert.h"
#include "dessertItem.h"
#include "weight.h"
#include "money.h"

using namespace std;

/* Function: Candy
 * Description: This function is the default constructor
 */
Candy::Candy(){
	wt = Weight();
	pricePerPound = Money();
}

/* Function: Candy
 * Description: This function is a constructor that passes candy name,
 * weight, and price
 */
Candy::Candy(std::string candyname, Weight w, Money price) : 
DessertItem(candyname){
	wt = Weight(w);
	pricePerPound = Money(price);
}

/* Function: Candy
 * Description: This function is a constructor that passes the information
 * from a file
 */
Candy::Candy(std::ifstream &infile) : DessertItem(infile){
	std::string temp;
	getline(infile, temp);
	wt = Weight((double)atof(temp.c_str()));
	getline(infile, temp);
	pricePerPound = Money((double)atof(temp.c_str()));
}

/* Function: ~Candy
 * Description: This function is the destructor 
 */
Candy::~Candy(){
}

/* Function: getCost
 * Description: This function will return the total price
 */
Money Candy::getCost(){
	Money total;
	total = Money((wt.getPounds() + (wt.getOunces() / 16.0)) *
	pricePerPound.dollarsAndCents());
}

/* Function: print
 * Description: This function will print the items weight, price per pound, 
 * and the name
 */
void Candy::print(){
	Money cost = Candy::getCost();
	std::cout << wt.getPounds() << " lbs " << wt.getOunces() << " oz @ " 
	<< pricePerPound.getDollars() << "." << pricePerPound.getCents() 
	<< " \\lb." << std::endl;
	DessertItem::print();
	std::cout << right << cost.getDollars() << "." << cost.getCents() 
	<< std::endl;	
}
