#include "weight.h"
#include "dessert.h"

Weight::Weight()
{
   pounds = 0;
   ounces = 0;
}



Weight::Weight(int lbs, int ounces)
{
   pounds = lbs;
   this->ounces = ounces;
}

Weight::Weight(double wt)
{
   double oz;
   pounds = static_cast<int> (wt);
   oz = (wt - pounds) * 16 + 0.5;
   ounces = static_cast<int>(oz);
   if(ounces > 16)
   {
     pounds++;
     ounces--;
   }
}

int Weight::getPounds()
{
   return pounds;
}
   
int Weight::getOunces()
{
   return ounces;
}

void Weight::setPounds(int lbs)
{
   pounds = lbs;
}

void Weight::setOunces(int oz)
{
      ounces = oz;
}

bool Weight::lessThan(Weight wt)
{
   int w1_total = 16 * pounds + ounces;
   int w2_total = 16 * wt.pounds + wt.ounces;

   if(w1_total < w2_total)
      return true;
   else
      return false;
}

bool Weight::operator< (Weight  wt)
{
   return (this->lessThan(wt));
}

