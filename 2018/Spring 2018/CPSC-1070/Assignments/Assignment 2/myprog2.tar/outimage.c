/* Author: Jeremy Holloway / jjhollo
*  CPSC-1070-001
*  Assignment 2
*  Due Date: 3/5/2018
*  Description: This file contains the write image function needed to 
*  open/create the output file and write data.
*/
#include "image.h"

/* Function: writeImage
*  Description: This function will open the designated file, write the header,
*  and use fwrite to write the image data to the file.
*/
void writeImage(char *fileName, image_t *mirroredImage) 
{
	FILE *outfile;
	outfile = fopen(fileName, "w");
	fprintf(outfile, "P6\n %d %d\n %d\n", mirroredImage->columns, 
	mirroredImage->rows, mirroredImage->brightness);
	int count = (mirroredImage->columns * mirroredImage->rows);
	fwrite(mirroredImage->image, sizeof(pixel_t), count, outfile);
	fclose(outfile);
}

