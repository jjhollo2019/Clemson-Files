/* Author: Jeremy Holloway / jjhollo
*  CPSC-1070-001
*  Assignment 2
*  Due Date: 3/5/2018
*  Description: This file will copy the image or return NULL if the 
*  image is empty
*/
#include "image.h"

/* Function: *mirror
*  Description: This function will first check if the image is NULL and 
*  return NULL if so, otherwise it will create a new pixel pointer which
*  will hold the image pixels and copy the pixels from the left to the
*  right while looping through the struct.
*/
image_t *mirror(image_t *inImage) 
{
	if (inImage->image == NULL)
		return (NULL);
	else {
		pixel_t temp; 
		pixel_t *holder;
		int mid = inImage->columns / 2;
		int a;
		int b;

		for (a = 0; a < inImage->rows; a++){
			holder = inImage->image + a * inImage->columns;
			for (b = 0; b < mid; b++){
				temp = holder[b];
				holder[inImage->columns - 1 - b] = temp;
			}
		}		
		return((image_t *) inImage);
	}
}
