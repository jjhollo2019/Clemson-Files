/* Author: Jeremy Holloway / jjhollo
*  CPSC-1070-001
*  Assignment 2
*  Due Date: 3/5/2018
*  Description: This program will malloc the memory needed for the new image
*  struct and allocated the values accordingly
*/
#include "image.h"

/* Function: *newImage
*  Description: This function will create a new struct and malloc the space 
*  needed for the struct and the image.
*/
image_t *newImage(int rows, int columns, int brightness) 
{
	image_t *new;
	new = (image_t *)malloc(sizeof(image_t));
	new->columns = columns;
	new->rows = rows;
	new->brightness = brightness;
	new->image = (pixel_t *)malloc(sizeof(pixel_t));
	
	return((image_t *) new); 
}
