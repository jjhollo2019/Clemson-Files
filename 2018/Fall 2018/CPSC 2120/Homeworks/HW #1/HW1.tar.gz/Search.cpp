/* Jeremy Holloway
 * CPSC-2120-001
 * Homework #1
 * 9/28/18
 */

#include <iostream>
#include <assert.h>
#include <string>
#include "Search.h"

using namespace std;

 int hash(string s, int table_size)
 {
  unsigned int i, h = 0;
  for (i = 0; i < s.length(); i++)
  {
   h = (h * 3547 + (unsigned int)s[i]) % table_size;
  }
  return h;
 }

 Page **allocate_table(int size)
 {
  Page **table = new Page *[size];
  for (int a = 0; a < size; a++)
   table[a] = NULL;
  return table;
 } 

 Node **allocate_wordTable(int size)
 {
  Node **wordTable = new Node *[size];
  for (int a = 0; a < size; a++)
   wordTable[a] = NULL;
  return wordTable;
 }

 Search::Search(int size)
 {
  int s = 20000000;
  this->size = size;
  table = allocate_table(size);
  wordTable = allocate_wordTable(s);
 }

 Search::~Search()
 {
  for (int a = 0; a < size; a++)
  {
   while (table[a] != NULL)
   {
    Page *temp = table[a];
    table[a] = table[a]->next;
    delete temp;
   }
  }
 }

 void Search::insert(string k)
 {
  int h = hash(k, size);//determine new item hash index
  double weight = 0.1 /(double) size;
  table[h] = new Page(k, table[h], weight);//insert new node
 }

 void Search::addLink(string page, string s)
 {
  int h = hash(page, size);
  table[h]->links = new Node(s, table[h]->links);
  table[h]->T++;
 }

 void Search::addWord(string page, string s)
 {
  int h = hash(page, size);
  table[h]->words = new Node(s, table[h]->words);
  while (wordTable[h] != NULL)
  {
   if (wordTable[h]->key == page){ return; }
   wordTable[h] = wordTable[h]->next;
  }
  wordTable[h] = new Node(page, wordTable[h]);
 }

 bool Search::find(string key)
 {
  int h = hash(key, size);//calaculate the hash of the key
  if (wordTable[h] == NULL) return false;
  Node *n = wordTable[h];//set n to the the target table element
  while (n != NULL) {//iterate through the element nodes
    if (n->key == key) return true;//break if key is found
    n = n->next;//continue if key is not found
  }
  return false;//return false if key is not present
 }
 
 bool Search::findPage(string key)
 {
  int h = hash(key, size);
  if (table[h] == NULL) return false;
  return true;
 }

 void Search::pageRank()
 {
  for (int a = 0; a < size; a++){
   if (table[a] != NULL){
    while (table[a]->links != NULL){
     table[a]->rankedWeight += 0.9 * (table[a]->weight / (double) table[a]->T);
     table[a]->links = table[a]->links->next;
    }
   }
  }
 }

 void Search::wordFind()
 {
  string wordToFind;
  cout << "What word would you like to search for?" << endl;
  cout << "Enter QUIT to exit" << endl;
  while (wordToFind != "QUIT")
  {
   cin >> wordToFind;
   int h = hash(wordToFind, size);
   if (wordTable[h] == NULL)
   {
    cout << "Word is not in the Table!" << endl;
   }
   while (wordTable[h] != NULL)
   {
    cout << wordTable[h]->key << endl;
    wordTable[h] = wordTable[h]->next;
   }
  }
 }
