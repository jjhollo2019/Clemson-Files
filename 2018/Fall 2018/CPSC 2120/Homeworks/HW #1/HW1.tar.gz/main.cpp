/* Jeremy Holloway
 * CPSC-2120-001
 * Homework #1
 * 9/28/18
 */

#include <cmath>
#include <string>
#include <fstream>
#include <iostream>
#include "Search.h"

using namespace std;

int main(void)
{
 string word1 = "";
 string pageName = "";
 string http = "http";
 int totalPages = 0;

 ifstream inFile("webpages.txt");
 while (inFile >> word1)
 {
  if (word1 == "NEWPAGE")
  {
   totalPages++;      
  }
 }
 inFile.clear();
 inFile.seekg(0);
 Search *A = new Search(totalPages);
 while (inFile >> word1)
 {
  if (word1 == "NEWPAGE")
  {
   inFile >> word1;
   (*A).insert(word1);
  }
 }
 inFile.clear();
 inFile.seekg(0);
 while (inFile >> word1)
 {
  if (word1 == "NEWPAGE")
  {
   inFile >> word1;
   pageName = word1;
  }
  else
  {
   if (word1[0] == 'h' && word1[1] == 't' && word1[2] == 't'
      && (*A).findPage(word1) == true)
   {
    (*A).addLink(pageName, word1); 
   }
   else 
   {
    (*A).addWord(pageName, word1); 
   }
  }
 }
 (*A).pageRank();
 (*A).wordFind();
 inFile.close();   
 return 0;
}
