/* Jeremy Holloway
 * CPSC-2120-001
 * Homework #1
 * 9/28/18
 */ 
#ifndef SEARCH_H
#define SEARCH_H

#include <cmath>
#include <string.h>
using namespace std;

struct Node
{
    string key;
    Node *next;
    Node(string k, Node *n){key = k; next = n;};
    Node(){key = " "; next = NULL;}
};

struct Page
{
    string name;
    double weight;
    double rankedWeight;
    double T;
    Node *links;
    Node *words;
    Page *next;
    Page(){name = " "; links = NULL; words = NULL; next = NULL;}
    Page(string s, Page *n, double w){name = s; links = NULL; 
         words = NULL; next = n; weight = w;}
};

struct WordList
{
	string pageName;
    WordList *next;
    WordList(string p, WordList *n){pageName = p; next = n;}
}; 

class Search
{
    private:
    Page **table;
    int size;
    Node **wordTable;

    public:
    Search(int size);
    ~Search();
    void addLink(string page, string s);
    void addWord(string page, string s);
    void insert(string k);
    void pageRank();
    void wordFind();
    bool find(string key);
    bool findPage(string key);
    void print(void);
};

#endif
